create definer = root@localhost trigger validaFecha
    before insert
    on meta
    for each row
BEGIN
    IF(now() < New.fechalimite) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No puedes añadir una fecha anterior al presente';
    END IF;
END;

